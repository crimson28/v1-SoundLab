import React,{Component} from 'react';
import { Text, View, Button, StyleSheet } from 'react-native';
import {Audio} from "expo-av";


class DJButton extends Component{

  playSound =async()=>{
    await Audio.Sound.createAsync(
      {uri:"http://www.imjohn.com/PresonusJensenXfrmrs/sounds/16-44.1/Electric-Tube10-Chord-short.wav"},
      {shouldPlay:true}

    );
  }

  render(){
    return(
        <Button color = {this.props.myColor} title = {this.props.myTitle} onPress = {this.playSound}/>


    )
  }
}



class Button1 extends Component{

  playSound =async()=>{
    await Audio.Sound.createAsync(
      {uri:"https://dight310.byu.edu/media/audio/FreeLoops.com/5/5/Piano%20Key%20C3-2862-Free-Loops.com.mp3"},
      {shouldPlay:true}

    );
  }

  render(){
    return(
        <Button color = {this.props.myColor} title = {this.props.myTitle} onPress = {this.playSound}/>


    )
  }
}


class Button2 extends Component{

  playSound =async()=>{
    await Audio.Sound.createAsync(
      {uri:"https://dight310.byu.edu/media/audio/FreeLoops.com/5/5/Marching%20Band-6948-Free-Loops.com.mp3"},
      {shouldPlay:true}

    );
  }

  render(){
    return(
        <Button color = {this.props.myColor} title = {this.props.myTitle} onPress = {this.playSound}/>


    )
  }
}

class Button3 extends Component{

  playSound =async()=>{
    await Audio.Sound.createAsync(
      {uri:"https://dight310.byu.edu/media/audio/FreeLoops.com/4/4/Horn%20Honk%20Funny-13749-Free-Loops.com.mp3"},
      {shouldPlay:true}

    );
  }

  render(){
    return(
        <Button color = {this.props.myColor} title = {this.props.myTitle} onPress = {this.playSound}/>


    )
  }
}
class Button4 extends Component{

  playSound =async()=>{
    await Audio.Sound.createAsync(
      {uri:"http://newt.phys.unsw.edu.au/music/saxophone/soprano/sounds/A4.mp3"},
      {shouldPlay:true}

    );
  }

  render(){
    return(
        <Button color = {this.props.myColor} title = {this.props.myTitle} onPress = {this.playSound} style = {{styles.buttonStyles,{}}} />


    )
  }
}



export default class App extends Component {
  render() {
    return (
      <View style = {{margin : 40, textAlign : "center", paddingTop : 20}}>
      <Text> Sound Lab </Text>
      <DJButton myColor = "rosybrown" myTitle = "Guitar" />
      <Button1 myColor = "olive" myTitle = "Piano"/>
      <Button2 myColor = "peru" myTitle = "Drum Beat"/>
      <Button3 myColor = "thistle" myTitle = "Sound Effect"/>
      <Button4 myColor = "cadetblue" myTitle = "Saxophone"/>

      
       </View>
       
    );
  }
}

//adding style sheet
const styles = StyleSheet.create({
  buttonStyles : {
    marginTop : 20,

  }
});

// export default class App extends React.Component{
//   render() {
//     return(
//       <View
//       style = {{width : 200, height : 200, marginLeft : 80, marginTop : 80}}>
//       <Button
      
//       title = "Sound1"
//       color = "coral"
//       onPress{() => Alert.alert('play sound 1')}
//       />
      
//       </View>

//     );


//   }
// }

